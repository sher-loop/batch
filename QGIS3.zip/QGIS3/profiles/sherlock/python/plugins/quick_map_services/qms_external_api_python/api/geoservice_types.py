class GeoServiceType(object):
    TMS = 'tms'
    WMS = 'wms'
    WFS = 'wfs'
    GeoJSON = 'geojson'

    enum = [
        TMS,
        WMS,
        WFS,
        GeoJSON
    ]

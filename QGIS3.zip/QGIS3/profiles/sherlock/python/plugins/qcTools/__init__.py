def classFactory(iface):
	#from script, import class
	from qcTools.qcTools import QC_Tools

	return QC_Tools(iface)

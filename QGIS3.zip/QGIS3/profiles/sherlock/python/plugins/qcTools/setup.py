import pkg_resources
import pip
package = 'geoalchemy2'
#try:										#check for package
#    version = pkg_resources.get_distribution(package).version
#    print(f"{package} version: {version}")
#except pkg_resources.DistributionNotFound: #if package not found
#    print(f"{package} is not installed.")
try:									#try to install it
    pip.main(['install',package ])
    print(f"{package} installed successfully.")
except Exception as e:					#error handling
    print(f"Exception occurred: {e}")
